import sys
import os
import gc
sys.path.append(os.path.abspath('.'))
from Measure_new import measure_final_score
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from numpy import mean, std
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score,recall_score,precision_score, f1_score,roc_auc_score
import pandas as pd
from utility import get_data,get_classifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import train_test_split
import os
import argparse
import copy
from sklearn.linear_model import LogisticRegression
# from WAE import data_dis

from time import *

from aif360.datasets import BinaryLabelDataset
from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector
from aif360.algorithms.inprocessing.adversarial_debiasing import AdversarialDebiasing

from aif360.algorithms.postprocessing.reject_option_classification import RejectOptionClassification
from aif360.algorithms.postprocessing.calibrated_eq_odds_postprocessing import CalibratedEqOddsPostprocessing
from aif360.algorithms.postprocessing.eq_odds_postprocessing import EqOddsPostprocessing
from aif360.datasets import AdultDataset, GermanDataset, CompasDataset, BankDataset,MEPSDataset19

from sklearn.calibration import CalibratedClassifierCV
from sko.PSO import PSO


parser = argparse.ArgumentParser()
parser.add_argument("-d", "--dataset", type=str, required=True,
                    choices = ['adult', 'german', 'compas', 'bank', 'mep'], help="Dataset name")
parser.add_argument("-c", "--clf", type=str, required=True,
                    choices = ['dl', 'dl2', 'dl3', 'dl4'], help="Classifier name")
parser.add_argument("-p", "--protected", type=str, required=True,
                    help="Protected attribute")

args = parser.parse_args()
dataset_used = args.dataset
attr = args.protected
clf_name = args.clf
#
scaler = MinMaxScaler()
data_label = 'Probability'


# dataset_used = 'adult'
# attr = 'sex'
# clf_name = 'dl2'

clf_temp = clf_name
# dataset_orig, privileged_groups,unprivileged_groups = get_data(dataset_used, attr)
dataset_orig, privileged_groups,unprivileged_groups, optim_options = get_data(dataset_used, attr)
results = {}
performance_index = ['accuracy', 'recall1', 'recall0', 'recall_macro', 'precision1', 'precision0', 'precision_macro', 'f1score1', 'f1score0', 'f1score_macro',  'mcc', 'spd', 'aod', 'eod','erd']
# performance_index = ['accuracy', 'recall', 'precision', 'f1score', 'mcc', 'spd',  'aod', 'eod']
for p_index in performance_index:
    results[p_index] = []

repeat_time = 50


# 构造去关联训练集, SF=sensitive teature, L=label,T=trasfer,O=original

def get_decorelated_training_set(df, alpha_1, alpha_2, SF, L):
    # 打乱数据集
    if dataset_used == 'bank':
        alpha_1 = alpha_2
        alpha_2 = 0

    df = df.sample(frac=1)

    SF0_L0 = df[(df[SF] == 0) & (df[L] == 0)]
    SF0_L1 = df[(df[SF] == 0) & (df[L] == 1)]
    SF1_L0 = df[(df[SF] == 1) & (df[L] == 0)]
    SF1_L1 = df[(df[SF] == 1) & (df[L] == 1)]

    # SF0_L1，其中alpha1部分 SF1_L1
    n_SF0_SF1 = int(SF0_L1.shape[0] * alpha_1)
    T_SF0_L1 = SF0_L1.iloc[:n_SF0_SF1].copy()
    O_SF0_L1 = SF0_L1.iloc[n_SF0_SF1:].copy()
    T_SF0_L1.loc[:, SF] = 1

    # SF1_L1，其中alpha1部分 SF0_L1
    n_SF1_SF0 = int(SF1_L1.shape[0] * alpha_2)
    T_SF1_L0 = SF1_L1.iloc[:n_SF1_SF0].copy()
    O_SF1_L0 = SF1_L1.iloc[n_SF1_SF0:].copy()
    T_SF1_L0.loc[:, SF] = 0
    # 原+a1转+(1-a1)原+a2转+(1-a2)原
    decorrelated_set = pd.concat([SF0_L0,
                                  SF1_L0,
                                  T_SF0_L1,
                                  O_SF0_L1,
                                  T_SF1_L0,
                                  O_SF1_L0], axis=0)

    # 打乱数据集
    decorrelated_set = decorrelated_set.sample(frac=1)

    return decorrelated_set

def training_data_scaler(training_set):
    scaler = MinMaxScaler()
    scaler.fit(training_set)
    training_set = pd.DataFrame(scaler.transform(training_set), columns=dataset_orig.columns)
    training_set = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=training_set,
                                      label_names=[data_label],
                                      protected_attribute_names=[attr])
    # dataset_orig_test_1 = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=dataset_orig_test_1,
    #                                          label_names=[data_label],
    #                                          protected_attribute_names=[attr])
    return training_set, scaler

def testing_data_scaler(testing_set, scaler):
    testing_set = pd.DataFrame(scaler.transform(testing_set), columns=dataset_orig.columns)
    testing_set = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=testing_set,
                                             label_names=[data_label],
                                             protected_attribute_names=[attr])
    return testing_set


# @profile
# @profile
def model_train_test(training_set, valid_set, valid_df_copy):
    clf = get_classifier(clf_name, training_set.features.shape[1:])
    clf.fit(training_set.features, training_set.labels, epochs=20, batch_size=256)
    clf_model = clf

    # clf_2 = get_classifier(clf_name, dataset_orig_train.features.shape[1:])
    # clf_2.fit(dataset_orig_train_new.features, dataset_orig_train_new.labels, epochs=20, batch_size=256)

    # clf = get_classifier(clf_name)
    # if clf_name == 'svm':
    #     clf = CalibratedClassifierCV(base_estimator=clf)
    # clf1 = clf.fit(training_set.features, training_set.labels)
    # clf = get_classifier(clf_name)

    # test_df_copy = copy.deepcopy(testing_set)
    pred_de1 = clf.predict(valid_set.features)

    res = []
    for i in range(len(pred_de1)):
        prob_t = pred_de1[i]
        if prob_t >= 0.5:
            res.append(1)
        else:
            res.append(0)

    valid_df_copy.labels = np.array(res)
    round_result = measure_final_score(valid_set, valid_df_copy, privileged_groups, unprivileged_groups)

    # training_set = None
    # del training_set
    # gc.collect()

    # MOO_metrics = (1 - round_result[0]) + (1 - round_result[3])
    MOO_metrics = (1 - round_result[0]) + (1 - round_result[9]) + (round_result[12]) + (round_result[13])
    #     print(MOO_metrics)
    return round_result, MOO_metrics, clf_model

def pre_model_train_test(training_set, valid_set, valid_df_copy):
    clf = LogisticRegression()
    # if clf_name == 'svm':
    #     clf = CalibratedClassifierCV(base_estimator=clf)
    clf1 = clf.fit(training_set.features, training_set.labels)
    # clf = get_classifier(clf_name)

    clf_model = clf1

    # test_df_copy = copy.deepcopy(testing_set)
    pred_de1 = clf1.predict_proba(valid_set.features)

    res = []
    for i in range(len(pred_de1)):
        prob_t = pred_de1[i][1]
        if prob_t >= 0.5:
            res.append(1)
        else:
            res.append(0)

    valid_df_copy.labels = np.array(res)
    round_result = measure_final_score(valid_set, valid_df_copy, privileged_groups, unprivileged_groups)

    # training_set = None
    # del training_set
    # gc.collect()

    # MOO_metrics = (1 - round_result[0]) + (1 - round_result[3])
    MOO_metrics = (1 - round_result[0]) + (1 - round_result[9]) + (round_result[12]) + (round_result[13])
    #     print(MOO_metrics)
    return round_result, MOO_metrics, clf_model

def model_test(clf1, testing_set, test_df_copy):
    pred_de1 = clf1.predict(testing_set.features)

    res = []
    for i in range(len(pred_de1)):
        prob_t = pred_de1[i]
        if prob_t >= 0.5:
            res.append(1)
        else:
            res.append(0)

    test_df_copy.labels = np.array(res)
    round_result = measure_final_score(testing_set, test_df_copy, privileged_groups, unprivileged_groups)

    # MOO_metrics = (1 - round_result[0]) + (1 - round_result[3])
    MOO_metrics = (1 - round_result[0]) + (1 - round_result[9]) + (round_result[12]) + (round_result[13])
    #     print(MOO_metrics)
    return round_result, MOO_metrics

# 优化算法：PSO opt

def PSO_func(x):
    global optimal_metrics
    global optimal_round_result
    global dataset_orig_train
    global testing_set
    global test_df_copy
    global valid_set
    global valid_df_copy
    global optimal_clf_model
    global model_set

    # x1, x2 = x  # alpha1, alpha2

    dataset_train = get_decorelated_training_set(dataset_orig_train, 0, x, attr, data_label)
    training_set, scaler = training_data_scaler(dataset_train)


    round_result, metrics, clf_model = pre_model_train_test(training_set, valid_set, valid_df_copy)
    # if (round_result[12] + round_result[13]) < 0.1:
    #     model_set.append(clf_model)
    #
    # # 挑在验证集上公平性较高且目标函数值更小的模型
    # if optimal_metrics > metrics:
    #     # print(round_result)
    #     optimal_metrics = metrics
    #     # optimal_round_result = round_result
    #     model_set.append(clf_model)
    #     # model = clf_model
    #     # if round_result[13] < 0.05:
        #     model_set.append(clf_model)
        # if model_set==[]:
        #     model_set.append(model)
    return metrics


global dataset_orig_train
# global dataset_orig_test
global optimal_metrics
global optimal_round_result
global testing_set
global test_df_copy
global valid_set
global valid_df_copy
global optimal_clf_model
global model_set
model_set = []
optimal_round_result = []
alpha_2_set = []

for pre in range(5):
    print("pre: ", pre)
    optimal_metrics = 10
    # if clf_flag==1:
    #     clf_name = 'lr'
    # clf_name = LogisticRegression()

    np.random.seed(pre)
    # split training data and test data
    dataset_orig_train, dataset_orig_vt = train_test_split(dataset_orig, test_size=0.3, shuffle=True)
    # dataset_orig_valid, dataset_orig_test = train_test_split(dataset_orig_vt, test_size=0.5, shuffle=True)
    # dataset_orig_valid1, dataset_orig_valid2 = train_test_split(dataset_orig_valid, test_size=0.5, shuffle=True)
    dataset_orig_valid = dataset_orig_train
    dataset_orig_test = dataset_orig_vt


    training_set, scaler = training_data_scaler(dataset_orig_train)
    valid_set = testing_data_scaler(dataset_orig_valid, scaler)
    # valid1_set = testing_data_scaler(dataset_orig_valid1, scaler)
    # valid2_set = testing_data_scaler(dataset_orig_valid2, scaler)
    testing_set = testing_data_scaler(dataset_orig_test, scaler)

    train_df_copy = copy.deepcopy(training_set)
    # valid1_df_copy = copy.deepcopy(valid1_set)
    # valid2_df_copy = copy.deepcopy(valid2_set)
    valid_df_copy = copy.deepcopy(valid_set)
    test_df_copy = copy.deepcopy(testing_set)

    pso = PSO(func=PSO_func, dim=1, pop=20, max_iter=1, lb=[0], ub=[0.5], w=0.8, c1=0.5, c2=0.5)
    pso.run()

    # alpha_1 = 0
    alpha_2_set.append(pso.gbest_x)
    print('Local optimal x:', pso.gbest_x)
    alpha_2 = mean(alpha_2_set)
    print('Optimal x: ', alpha_2)

for r in range(repeat_time):
    print(r)
    optimal_metrics = 50
    clf_name = clf_temp
    np.random.seed(r)
    # split training data and test data
    dataset_orig_train, dataset_orig_vt = train_test_split(dataset_orig, test_size=0.3, shuffle=True)
    # dataset_orig_valid, dataset_orig_test = train_test_split(dataset_orig_vt, test_size=0.5, shuffle=True)
    # dataset_orig_valid = dataset_orig_train
    dataset_orig_valid = dataset_orig_train
    dataset_orig_test = dataset_orig_vt

    training_set, scaler = training_data_scaler(dataset_orig_train)
    valid_set = testing_data_scaler(dataset_orig_valid, scaler)
    testing_set = testing_data_scaler(dataset_orig_test, scaler)

    valid_df_copy = copy.deepcopy(valid_set)
    test_df_copy = copy.deepcopy(testing_set)

    # pso = PSO(func=PSO_func, dim=2, pop=20, max_iter=5, lb=[0, 0], ub=[1, 1], w=0.8, c1=0.5, c2=0.5)
    # pso.run()
    #
    # temp_metrics = 1
    # for model in model_set:
    #     temp_result, metrics = model_test(model, testing_set, test_df_copy)
    #     # print()
    #     if temp_metrics > metrics:
    #         temp_metrics = metrics
    #         optimal_clf_model = model
    alpha_1 = 0
    # alpha_2 = 0.30
    print(alpha_2)
    dataset_train = get_decorelated_training_set(dataset_orig_train, alpha_1, alpha_2, attr, data_label)
    training_set, scaler = training_data_scaler(dataset_train)

    round_result, metrics, clf_model = model_train_test(training_set, valid_set, valid_df_copy)

    optimal_round_result, optimal_metrics = model_test(clf_model, testing_set, test_df_copy)

    # optimal_round_result, moo_metrics = model_test(optimal_clf_model, testing_set, test_df_copy)
    # print(optimal_round_result)
    # model_set = []

    for i in range(len(performance_index)):
        results[performance_index[i]].append(optimal_round_result[i])

val_name = "fitness_{}_{}_{}.txt".format(clf_name, dataset_used, attr)
fout = open(val_name, 'w')
for p_index in performance_index:
    fout.write(p_index + '\t')
    for i in range(repeat_time):
        fout.write('%f\t' % results[p_index][i])
    fout.write('%f\t%f\n' % (mean(results[p_index]), std(results[p_index])))
fout.close()
